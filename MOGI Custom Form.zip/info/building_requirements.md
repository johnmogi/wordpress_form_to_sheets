
- tabs?

date	customer-name	phone-number	source	שיחה	פרטים	email	message	אני מאשר/ת קבלת חומר שיווקי	נשלח מ	referer																

- guide to bring it into sheets
